﻿
namespace Group15_project
{
    partial class TaskEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnMaintainProfile = new System.Windows.Forms.Button();
            this.btnTrackLocation = new System.Windows.Forms.Button();
            this.btnViewPayment = new System.Windows.Forms.Button();
            this.btnBrowseTask = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(590, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 17);
            this.label1.TabIndex = 8;
            this.label1.Text = "label1";
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(265, 69);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1013, 803);
            this.panel2.TabIndex = 7;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnMaintainProfile);
            this.panel1.Controls.Add(this.btnTrackLocation);
            this.panel1.Controls.Add(this.btnViewPayment);
            this.panel1.Controls.Add(this.btnBrowseTask);
            this.panel1.Location = new System.Drawing.Point(-32, -4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(296, 566);
            this.panel1.TabIndex = 6;
            // 
            // btnMaintainProfile
            // 
            this.btnMaintainProfile.Location = new System.Drawing.Point(55, 47);
            this.btnMaintainProfile.Name = "btnMaintainProfile";
            this.btnMaintainProfile.Size = new System.Drawing.Size(168, 43);
            this.btnMaintainProfile.TabIndex = 5;
            this.btnMaintainProfile.Text = "Maintain Profile";
            this.btnMaintainProfile.UseVisualStyleBackColor = true;
            this.btnMaintainProfile.Click += new System.EventHandler(this.btnMaintainProfile_Click);
            // 
            // btnTrackLocation
            // 
            this.btnTrackLocation.Location = new System.Drawing.Point(55, 261);
            this.btnTrackLocation.Name = "btnTrackLocation";
            this.btnTrackLocation.Size = new System.Drawing.Size(168, 43);
            this.btnTrackLocation.TabIndex = 3;
            this.btnTrackLocation.Text = "Track Location";
            this.btnTrackLocation.UseVisualStyleBackColor = true;
            this.btnTrackLocation.Click += new System.EventHandler(this.btnTrackLocation_Click);
            // 
            // btnViewPayment
            // 
            this.btnViewPayment.Location = new System.Drawing.Point(55, 370);
            this.btnViewPayment.Name = "btnViewPayment";
            this.btnViewPayment.Size = new System.Drawing.Size(168, 43);
            this.btnViewPayment.TabIndex = 2;
            this.btnViewPayment.Text = "View Payment";
            this.btnViewPayment.UseVisualStyleBackColor = true;
            this.btnViewPayment.Click += new System.EventHandler(this.btnViewPayment_Click);
            // 
            // btnBrowseTask
            // 
            this.btnBrowseTask.Location = new System.Drawing.Point(55, 146);
            this.btnBrowseTask.Name = "btnBrowseTask";
            this.btnBrowseTask.Size = new System.Drawing.Size(168, 43);
            this.btnBrowseTask.TabIndex = 1;
            this.btnBrowseTask.Text = "Browse Task";
            this.btnBrowseTask.UseVisualStyleBackColor = true;
            this.btnBrowseTask.Click += new System.EventHandler(this.btnBrowseTask_Click);
            // 
            // TaskEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1308, 892);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "TaskEmployee";
            this.Text = "TaskEmployee";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnMaintainProfile;
        private System.Windows.Forms.Button btnTrackLocation;
        private System.Windows.Forms.Button btnViewPayment;
        private System.Windows.Forms.Button btnBrowseTask;
    }
}