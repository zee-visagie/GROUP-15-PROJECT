﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Group15_project
{

    public partial class MaintainTasks : Form
    {
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Siphokazi\Desktop\Group15_project\Tasks.mdf;Integrated Security=True";

        public MaintainTasks()
        {
            InitializeComponent();
        }

        private void btnInsertTasks_Click(object sender, EventArgs e)
        {
            int taskNum = int.Parse(txtTaskNum.Text);
            string taskName = txtNameTask.Text;
            string taskLocation = txtLocationTask.Text;
            float taskDuration = float.Parse(txtDurationOfTask.Text);
            decimal taskPrice = decimal.Parse(txtPriceOfTask.Text);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string query = "INSERT INTO TaskDetails VALUES (@TaskNum, @TaskName, @TaskLocation, @TaskDuration, @TaskPrice )";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@TaskNum", taskNum);
                        command.Parameters.AddWithValue("@TaskName", taskName);
                        command.Parameters.AddWithValue("@TaskLocation", taskLocation);
                        command.Parameters.AddWithValue("@TaskDuration", taskDuration);
                        command.Parameters.AddWithValue("@TaskPrice", taskPrice);


                        int rowsAffected = command.ExecuteNonQuery();

                        try
                        {
                            connection.Open();

                            string Insertquery = "SELECT * FROM TaskDetails"; // Replace with your table name
                            SqlDataAdapter adapter = new SqlDataAdapter(Insertquery, connection);
                            DataTable dataTable = new DataTable();
                            adapter.Fill(dataTable);

                            dgTasks.DataSource = dataTable;

                        }
                        catch (SqlException ex)
                        {
                            MessageBox.Show(ex.Message);
                        }



                        if (rowsAffected > 0)
                        {

                            MessageBox.Show("task inserted successfully!");

                        }
                        else
                        {
                            MessageBox.Show("task inserting failed.");
                        }


                    }
                    connection.Close();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string TaskNum = txtTaskNum.Text;

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string deleteQuery = "DELETE FROM TaskDetails WHERE TaskNum = @TaskNum";
                    SqlCommand command = new SqlCommand(deleteQuery, connection);
                    command.Parameters.AddWithValue("@TaskNum", TaskNum);


                    int rowsAffected = command.ExecuteNonQuery();

                    try
                    {
                        connection.Open();

                        string Deletequery = "SELECT * FROM TaskDetails"; // Replace with your table name
                        SqlDataAdapter adapter = new SqlDataAdapter(Deletequery, connection);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        dgTasks.DataSource = dataTable;

                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Task deleted successfully!");
                    }
                    else
                    {
                        MessageBox.Show("Task not found or delete failed.");
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int taskNum = int.Parse(txtTaskNum.Text);
            string taskName = txtNameTask.Text;
            string taskLocation = txtLocationTask.Text;
            float taskDuration = float.Parse(txtDurationOfTask.Text);
            decimal taskPrice = decimal.Parse(txtPriceOfTask.Text);

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string updateQuery = "UPDATE TaskDetails SET TaskName = @TaskName, TaskLocation = @TaskLocation, TaskDuration = @TaskDuration, TaskPrice = @TaskPrice WHERE TaskNum = @TaskNum";
                    SqlCommand command = new SqlCommand(updateQuery, connection);

                    command.Parameters.AddWithValue("@TaskNum", taskNum);
                    command.Parameters.AddWithValue("@TaskName", taskName);
                    command.Parameters.AddWithValue("@TaskLocation", taskLocation);
                    command.Parameters.AddWithValue("@TaskDuration", taskDuration);
                    command.Parameters.AddWithValue("@Email", taskDuration);
                    command.Parameters.AddWithValue("@TaskPrice", taskPrice);

                    int rowsAffected = command.ExecuteNonQuery();

                    try
                    {
                        connection.Open();

                        string Updatequery = "SELECT * FROM TaskDetails"; // Replace with your table name
                        SqlDataAdapter adapter = new SqlDataAdapter(Updatequery, connection);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        dgTasks.DataSource = dataTable;

                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Task information updated successfully!");
                    }
                    else
                    {
                        MessageBox.Show("Task not found or update failed.");
                    }
                }
            }
            catch(SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }


        }
    

        private void MaintainTasks_Load(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {       connection.Open();

                    string query = "SELECT * FROM TaskDetails"; // Replace with your table name
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    dgTasks.DataSource = dataTable;

                }
                catch(SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                
            }
        }
    }
}
  
