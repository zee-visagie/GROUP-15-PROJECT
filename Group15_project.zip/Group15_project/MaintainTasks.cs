﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Group15_project
{

    public partial class MaintainTasks : Form
    {
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Siphokazi\Desktop\Group15_project\Profiles.mdf;Integrated Security=True";

        public MaintainTasks()
        {
            InitializeComponent();
        }

        private void btnInsertTasks_Click(object sender, EventArgs e)
        {

            string taskName = txtNameTask.Text;
            string taskLocation = txtLocationTask.Text;
            float taskDuration = float.Parse(txtDurationOfTask.Text);
            decimal taskPrice = decimal.Parse(txtPriceOfTask.Text);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string query = "INSERT INTO [Table] VALUES (@TaskName, @TaskLocation, @TaskDuration, @TaskPrice )";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@TaskName", taskName);
                        command.Parameters.AddWithValue("@TaskLocation", taskLocation);
                        command.Parameters.AddWithValue("@TaskDuration", taskDuration);
                        command.Parameters.AddWithValue("@TaskPrice", taskPrice);


                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {

                            MessageBox.Show("task inserted successfully!");

                        }
                        else
                        {
                            MessageBox.Show("task inserting failed.");
                        }
                    }
                    connection.Close();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string TaskNum = txtTaskNum.Text;

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string deleteQuery = "DELETE FROM [Table] WHERE TaskNum = @TaskNum";
                    SqlCommand command = new SqlCommand(deleteQuery, connection);
                    command.Parameters.AddWithValue("@TaskNum", TaskNum);


                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Task deleted successfully!");
                    }
                    else
                    {
                        MessageBox.Show("Task not found or delete failed.");
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int taskNum = int.Parse(txtTaskNum.Text);
            string taskName = txtNameTask.Text;
            string taskLocation = txtLocationTask.Text;
            float taskDuration = float.Parse(txtDurationOfTask.Text);
            decimal taskPrice = decimal.Parse(txtPriceOfTask.Text);

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string updateQuery = "UPDATE [Table] SET TaskName = @TaskName, TaskLocation = @TaskLocation, TaskDuration = @TaskDuration, TaskPrice = @TaskPrice WHERE TaskNum = @TaskNum";
                    SqlCommand command = new SqlCommand(updateQuery, connection);

                    command.Parameters.AddWithValue("@TaskNum", taskNum);
                    command.Parameters.AddWithValue("@TaskName", taskName);
                    command.Parameters.AddWithValue("@TaskLocation", taskLocation);
                    command.Parameters.AddWithValue("@TaskDuration", taskDuration);
                    command.Parameters.AddWithValue("@Email", taskDuration);
                    command.Parameters.AddWithValue("@TaskPrice", taskPrice);

                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Task information updated successfully!");
                    }
                    else
                    {
                        MessageBox.Show("Task not found or update failed.");
                    }
                }
            }
            catch(SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }


        }
    

        private void MaintainTasks_Load(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {       connection.Open();

                        string query = "SELECT * FROM [Table] "; 
                        SqlCommand command = new SqlCommand(query, connection);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            lbTasks.Items.Clear();
                            while (reader.Read())
                            {
                                lbTasks.Items.Add(reader.GetValue(0));
                            }
                        }
                    
                }
                catch(SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                
            }
        }
    }
}
  
