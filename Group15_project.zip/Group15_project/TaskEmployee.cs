﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group15_project
{
    public partial class TaskEmployee : Form
    {
        private MaintainProfiles maintainprofilesform;
        private AvailableTasks availableTasksform;
        private TrackLocation trackLocationform;
        private Receipt receiptForm;
        public TaskEmployee()
        {
            InitializeComponent();
        }

        private void btnMaintainProfile_Click(object sender, EventArgs e)
        {
            if (maintainprofilesform == null)
            {
                maintainprofilesform = new MaintainProfiles();
                maintainprofilesform.TopLevel = false;
                panel2.Controls.Add(maintainprofilesform);
            }

            maintainprofilesform.Show();
        }

        private void btnBrowseTask_Click(object sender, EventArgs e)
        {
            if (availableTasksform == null)
            {
                availableTasksform = new AvailableTasks();
                availableTasksform.TopLevel = false;
                panel2.Controls.Add(availableTasksform);
            }

            availableTasksform.Show();
        }

        private void btnTrackLocation_Click(object sender, EventArgs e)
        {
            if (trackLocationform == null)
            {
                trackLocationform = new TrackLocation();
                trackLocationform.TopLevel = false;
                panel2.Controls.Add(trackLocationform);
            }

            trackLocationform.Show();
        }

        private void btnViewPayment_Click(object sender, EventArgs e)
        {
            if (receiptForm == null)
            {
                receiptForm = new Receipt();
                receiptForm.TopLevel = false;
                panel2.Controls.Add(receiptForm);
            }

            receiptForm.Show();
        }

        private void btnSignOut_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
