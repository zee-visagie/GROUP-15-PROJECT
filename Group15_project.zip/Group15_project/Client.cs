﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group15_project
{
    public partial class Client : Form
    {
        private MaintainProfiles maintainprofilesform;
        private MaintainTasks maintaintasksform;
        private RateaAndReview rateandreviewform;
        private MakePayments makepaymentsform;
        public Client()
        {
            InitializeComponent();
        }

        private void btnUpdateProfile_Click(object sender, EventArgs e)
        {
            if (maintainprofilesform == null)
            {
                maintainprofilesform = new MaintainProfiles();
                maintainprofilesform.TopLevel = false;
                panel2.Controls.Add(maintainprofilesform);
            }

            maintainprofilesform.Show();
        }

        private void btnMaintainTask_Click(object sender, EventArgs e)
        {
            if (maintaintasksform == null)
            {
                maintaintasksform = new MaintainTasks();
                maintaintasksform.TopLevel = false;
                panel2.Controls.Add(maintaintasksform);
            }

            maintaintasksform.Show();
        }

        private void btnReviewAndRate_Click(object sender, EventArgs e)
        {
            if (rateandreviewform == null)
            {
                rateandreviewform = new RateaAndReview();
                rateandreviewform.TopLevel = false;
                panel2.Controls.Add(rateandreviewform);
            }

            rateandreviewform.Show();
        }

        private void btnMakePayment_Click(object sender, EventArgs e)
        {
            if (makepaymentsform == null)
            {
                makepaymentsform = new MakePayments();
                makepaymentsform.TopLevel = false;
                panel2.Controls.Add(makepaymentsform);
            }

            makepaymentsform.Show();
        }
    }
}
