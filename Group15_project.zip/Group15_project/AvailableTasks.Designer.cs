﻿
namespace Group15_project
{
    partial class AvailableTasks
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lbListsOfTasksToDo = new System.Windows.Forms.ListBox();
            this.btnAcceptTask = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtSearchTask = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Algerian", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(869, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(291, 22);
            this.label3.TabIndex = 10;
            this.label3.Text = "Accepted/Seleted Tasks";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(873, 77);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(855, 452);
            this.listBox1.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Algerian", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(39, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(235, 22);
            this.label1.TabIndex = 8;
            this.label1.Text = "Select task/s to do";
            // 
            // lbListsOfTasksToDo
            // 
            this.lbListsOfTasksToDo.FormattingEnabled = true;
            this.lbListsOfTasksToDo.ItemHeight = 16;
            this.lbListsOfTasksToDo.Location = new System.Drawing.Point(32, 77);
            this.lbListsOfTasksToDo.Name = "lbListsOfTasksToDo";
            this.lbListsOfTasksToDo.Size = new System.Drawing.Size(802, 452);
            this.lbListsOfTasksToDo.TabIndex = 7;
            this.lbListsOfTasksToDo.SelectedIndexChanged += new System.EventHandler(this.lbListsOfTasksToDo_SelectedIndexChanged);
            // 
            // btnAcceptTask
            // 
            this.btnAcceptTask.Location = new System.Drawing.Point(573, 602);
            this.btnAcceptTask.Name = "btnAcceptTask";
            this.btnAcceptTask.Size = new System.Drawing.Size(261, 45);
            this.btnAcceptTask.TabIndex = 11;
            this.btnAcceptTask.Text = "Accept Tasks";
            this.btnAcceptTask.UseVisualStyleBackColor = true;
            this.btnAcceptTask.Click += new System.EventHandler(this.btnAcceptTask_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(32, 602);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(139, 45);
            this.btnSearch.TabIndex = 12;
            this.btnSearch.Text = "Search Tasks";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtSearchTask
            // 
            this.txtSearchTask.Location = new System.Drawing.Point(130, 563);
            this.txtSearchTask.Name = "txtSearchTask";
            this.txtSearchTask.Size = new System.Drawing.Size(295, 22);
            this.txtSearchTask.TabIndex = 13;
            this.txtSearchTask.TextChanged += new System.EventHandler(this.txtSearchTask_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 566);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 17);
            this.label2.TabIndex = 14;
            this.label2.Text = "Search task:";
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(187, 602);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(136, 45);
            this.btnRefresh.TabIndex = 15;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(570, 582);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(355, 17);
            this.label4.TabIndex = 16;
            this.label4.Text = "select a single task and press the button to accept task";
            // 
            // AvailableTasks
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1743, 659);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtSearchTask);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.btnAcceptTask);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbListsOfTasksToDo);
            this.Name = "AvailableTasks";
            this.Text = "AvailableTasks";
            this.Load += new System.EventHandler(this.AvailableTasks_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lbListsOfTasksToDo;
        private System.Windows.Forms.Button btnAcceptTask;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtSearchTask;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Label label4;
    }
}