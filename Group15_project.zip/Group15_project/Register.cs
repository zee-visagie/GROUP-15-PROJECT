﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Group15_project
{
    public partial class Register : Form
    {
      

        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Siphokazi\Desktop\Group15_project\Profiles.mdf;Integrated Security=True";
        
        public Register()
        {
            InitializeComponent();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            
            

        }
       

        private void btnRegister_Click_1(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;
            string confirmPassword = txtConfirmPassword.Text;
            string name = txtName.Text;
            string surname = txtName.Text;
            string email = txtEmail.Text;
            int contactNum = int.Parse(txtContactNumber.Text);
            string userCategory = CBUser.SelectedItem.ToString();

            if (password == confirmPassword)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();

                        string query = "INSERT INTO UserDetails VALUES  (@Username, @Password, @Name, @Surname, @Email, @ContactNum, @UserCategory )";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@Username", username);
                            command.Parameters.AddWithValue("@Password", password);
                            command.Parameters.AddWithValue("@Name", name);
                            command.Parameters.AddWithValue("@Surname", surname);
                            command.Parameters.AddWithValue("@Email", email);
                            command.Parameters.AddWithValue("@ContactNum", contactNum);
                            command.Parameters.AddWithValue("@UserCategory", userCategory);


                            int rowsAffected = command.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                this.Hide();
                                MessageBox.Show("User registerd successfully!");
                                Form1 loginform = new Form1();
                                loginform.ShowDialog();
                            }
                            else
                            {
                                MessageBox.Show("User registration failed.");
                            }
                        }
                        connection.Close();
                    }
                    catch(SqlException ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    
                }
            }
            else
            {
                MessageBox.Show("Passwords do not match. Re enter password");
                txtConfirmPassword.Text = "";
                txtPassword.Text = "";
                txtPassword.Focus();
            }
        }

        private void txtContactNumber_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtSurname_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtConfirmPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

        }

        private void CBUser_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
