﻿
namespace Group15_project
{
    partial class MaintainTasks
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label6 = new System.Windows.Forms.Label();
            this.btnInsertTasks = new System.Windows.Forms.Button();
            this.txtDurationOfTask = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtLocationTask = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtPriceOfTask = new System.Windows.Forms.TextBox();
            this.txtNameTask = new System.Windows.Forms.TextBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.txtTaskNum = new System.Windows.Forms.TextBox();
            this.dgTasks = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgTasks)).BeginInit();
            this.SuspendLayout();
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Algerian", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(138, 31);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(185, 22);
            this.label6.TabIndex = 30;
            this.label6.Text = "Maintain Tasks";
            // 
            // btnInsertTasks
            // 
            this.btnInsertTasks.Location = new System.Drawing.Point(61, 485);
            this.btnInsertTasks.Name = "btnInsertTasks";
            this.btnInsertTasks.Size = new System.Drawing.Size(293, 32);
            this.btnInsertTasks.TabIndex = 29;
            this.btnInsertTasks.Text = "Insert Tasks";
            this.btnInsertTasks.UseVisualStyleBackColor = true;
            this.btnInsertTasks.Click += new System.EventHandler(this.btnInsertTasks_Click);
            // 
            // txtDurationOfTask
            // 
            this.txtDurationOfTask.Location = new System.Drawing.Point(233, 244);
            this.txtDurationOfTask.Name = "txtDurationOfTask";
            this.txtDurationOfTask.Size = new System.Drawing.Size(388, 22);
            this.txtDurationOfTask.TabIndex = 28;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(36, 259);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(153, 17);
            this.label5.TabIndex = 27;
            this.label5.Text = "Duration of task(Digits)";
            // 
            // txtLocationTask
            // 
            this.txtLocationTask.Location = new System.Drawing.Point(233, 184);
            this.txtLocationTask.Name = "txtLocationTask";
            this.txtLocationTask.Size = new System.Drawing.Size(388, 22);
            this.txtLocationTask.TabIndex = 26;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(36, 189);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 17);
            this.label3.TabIndex = 25;
            this.label3.Text = "Location of task";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(36, 335);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 17);
            this.label2.TabIndex = 24;
            this.label2.Text = "Price of task";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(36, 128);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 17);
            this.label1.TabIndex = 23;
            this.label1.Text = "Name of task:";
            // 
            // txtPriceOfTask
            // 
            this.txtPriceOfTask.Location = new System.Drawing.Point(233, 330);
            this.txtPriceOfTask.Name = "txtPriceOfTask";
            this.txtPriceOfTask.Size = new System.Drawing.Size(388, 22);
            this.txtPriceOfTask.TabIndex = 22;
            // 
            // txtNameTask
            // 
            this.txtNameTask.Location = new System.Drawing.Point(233, 123);
            this.txtNameTask.Name = "txtNameTask";
            this.txtNameTask.Size = new System.Drawing.Size(388, 22);
            this.txtNameTask.TabIndex = 21;
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(786, 485);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(293, 32);
            this.btnDelete.TabIndex = 31;
            this.btnDelete.Text = "Delete Tasks";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(427, 485);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(293, 32);
            this.btnUpdate.TabIndex = 32;
            this.btnUpdate.Text = "Update Tasks";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(36, 79);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(101, 17);
            this.label4.TabIndex = 34;
            this.label4.Text = "Task Number: ";
            // 
            // txtTaskNum
            // 
            this.txtTaskNum.Location = new System.Drawing.Point(233, 74);
            this.txtTaskNum.Name = "txtTaskNum";
            this.txtTaskNum.Size = new System.Drawing.Size(388, 22);
            this.txtTaskNum.TabIndex = 35;
            // 
            // dgTasks
            // 
            this.dgTasks.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgTasks.Location = new System.Drawing.Point(644, 38);
            this.dgTasks.Name = "dgTasks";
            this.dgTasks.RowHeadersWidth = 51;
            this.dgTasks.RowTemplate.Height = 24;
            this.dgTasks.Size = new System.Drawing.Size(716, 425);
            this.dgTasks.TabIndex = 36;
            // 
            // MaintainTasks
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1372, 556);
            this.Controls.Add(this.dgTasks);
            this.Controls.Add(this.txtTaskNum);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btnInsertTasks);
            this.Controls.Add(this.txtDurationOfTask);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtLocationTask);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtPriceOfTask);
            this.Controls.Add(this.txtNameTask);
            this.Name = "MaintainTasks";
            this.Text = "MaintainTasks";
            this.Load += new System.EventHandler(this.MaintainTasks_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgTasks)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnInsertTasks;
        private System.Windows.Forms.TextBox txtDurationOfTask;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtLocationTask;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtPriceOfTask;
        private System.Windows.Forms.TextBox txtNameTask;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtTaskNum;
        private System.Windows.Forms.DataGridView dgTasks;
    }
}