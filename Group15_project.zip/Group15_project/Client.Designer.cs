﻿
namespace Group15_project
{
    partial class Client
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnUpdateProfile = new System.Windows.Forms.Button();
            this.btnReviewAndRate = new System.Windows.Forms.Button();
            this.btnMakePayment = new System.Windows.Forms.Button();
            this.btnMaintainTask = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(676, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 17);
            this.label1.TabIndex = 5;
            this.label1.Text = "label1";
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(351, 66);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(978, 755);
            this.panel2.TabIndex = 4;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(470, 24);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnUpdateProfile);
            this.panel1.Controls.Add(this.btnReviewAndRate);
            this.panel1.Controls.Add(this.btnMakePayment);
            this.panel1.Controls.Add(this.btnMaintainTask);
            this.panel1.Location = new System.Drawing.Point(54, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(296, 646);
            this.panel1.TabIndex = 3;
            // 
            // btnUpdateProfile
            // 
            this.btnUpdateProfile.Location = new System.Drawing.Point(55, 47);
            this.btnUpdateProfile.Name = "btnUpdateProfile";
            this.btnUpdateProfile.Size = new System.Drawing.Size(168, 43);
            this.btnUpdateProfile.TabIndex = 5;
            this.btnUpdateProfile.Text = "Maintain Profile";
            this.btnUpdateProfile.UseVisualStyleBackColor = true;
            this.btnUpdateProfile.Click += new System.EventHandler(this.btnUpdateProfile_Click);
            // 
            // btnReviewAndRate
            // 
            this.btnReviewAndRate.Location = new System.Drawing.Point(55, 256);
            this.btnReviewAndRate.Name = "btnReviewAndRate";
            this.btnReviewAndRate.Size = new System.Drawing.Size(168, 43);
            this.btnReviewAndRate.TabIndex = 3;
            this.btnReviewAndRate.Text = "Review And Rate";
            this.btnReviewAndRate.UseVisualStyleBackColor = true;
            this.btnReviewAndRate.Click += new System.EventHandler(this.btnReviewAndRate_Click);
            // 
            // btnMakePayment
            // 
            this.btnMakePayment.Location = new System.Drawing.Point(55, 372);
            this.btnMakePayment.Name = "btnMakePayment";
            this.btnMakePayment.Size = new System.Drawing.Size(168, 43);
            this.btnMakePayment.TabIndex = 2;
            this.btnMakePayment.Text = "Make Payment";
            this.btnMakePayment.UseVisualStyleBackColor = true;
            this.btnMakePayment.Click += new System.EventHandler(this.btnMakePayment_Click);
            // 
            // btnMaintainTask
            // 
            this.btnMaintainTask.Location = new System.Drawing.Point(55, 146);
            this.btnMaintainTask.Name = "btnMaintainTask";
            this.btnMaintainTask.Size = new System.Drawing.Size(168, 43);
            this.btnMaintainTask.TabIndex = 1;
            this.btnMaintainTask.Text = "Maintain Task";
            this.btnMaintainTask.UseVisualStyleBackColor = true;
            this.btnMaintainTask.Click += new System.EventHandler(this.btnMaintainTask_Click);
            // 
            // Client
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1341, 821);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Client";
            this.Text = "Client";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnUpdateProfile;
        private System.Windows.Forms.Button btnReviewAndRate;
        private System.Windows.Forms.Button btnMakePayment;
        private System.Windows.Forms.Button btnMaintainTask;
    }
}