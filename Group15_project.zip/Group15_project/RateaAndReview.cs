﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group15_project
{
    public partial class RateaAndReview : Form
    {
        public RateaAndReview()
        {
            InitializeComponent();
        }
    }
}
