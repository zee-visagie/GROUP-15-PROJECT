﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group15_project
{
    public partial class RateaAndReview : Form
    {
        public RateaAndReview()
        {
            InitializeComponent();
        }

        private void RateaAndReview_Load(object sender, EventArgs e)
        {
            for (int i = 1; i <= 5; i++)
            {
                cbRating.Items.Add(i);
            }
            cbRating.SelectedIndex = 0;
        }

        private void btnSubmitQuery_Click(object sender, EventArgs e)
        {
            int rating = (int)cbRating.SelectedItem;
            string review = txtReview.Text;

            this.Hide();
            MessageBox.Show("You've rated with " + rating + " stars.\nReview: " + review);
            
        }
    }
    
}
