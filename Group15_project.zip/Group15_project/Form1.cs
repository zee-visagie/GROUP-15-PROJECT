﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Group15_project
{
    public partial class Form1 : Form
    {
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Siphokazi\Desktop\Group15_project\Profiles.mdf;Integrated Security=True";

        public Form1()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Register registerform = new Register();
            registerform.ShowDialog();
        }

        private void cbUserType_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Siphokazi\Desktop\Group15_project\Profiles.mdf;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"SELECT DISTINCT UserCategory FROM UserDetails";
                SqlCommand command = new SqlCommand(query, connection);

                try
                {
                    connection.Open();

                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        cbUserType.Items.Add(reader["UserCategory"].ToString());
                    }

                    reader.Close();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;
            string userCategory = cbUserType.SelectedItem.ToString();


            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {

                    connection.Open();

                    string query = "SELECT * FROM UserDetails WHERE Username = @Username AND Password = @Password AND UserCategory = @UserCategory";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Username", username);
                        command.Parameters.AddWithValue("@Password", password);
                        command.Parameters.AddWithValue("@UserCategory", userCategory);

                        int userCount = Convert.ToInt32(command.ExecuteScalar());


                        if (userCount > 0)
                        {
                            MessageBox.Show("Login successful!");
                            
                            if(cbUserType.SelectedItem.ToString() == "Client")
                            {
                                this.Hide();
                                Client clientform = new Client();
                                clientform.ShowDialog();
                            }
                            else if(cbUserType.SelectedItem.ToString() == "Task Employee")
                            {
                                this.Hide();
                                TaskEmployee taskemployeeform = new TaskEmployee();
                                taskemployeeform.ShowDialog();
                            }
                        }
                        else
                        {
                            MessageBox.Show("Login failed.");
                        }
                    }
                }
            }
            catch(SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
          


        }
    }
}
