﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Group15_project
{
    public partial class AvailableTasks : Form
    {
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Siphokazi\Desktop\Group15_project\Tasks.mdf;Integrated Security=True";

        public AvailableTasks()
        {
            InitializeComponent();
        }

        private void AvailableTasks_Load(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT * FROM TaskDetails"; 
                SqlCommand command = new SqlCommand(query, connection);

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    lbListsOfTasksToDo.Items.Clear();
                    //lbListsOfTasksToDo.Items.Add(headings)
                    while (reader.Read())
                    {
                        lbListsOfTasksToDo.Items.Add(reader.GetValue(0) + "\t" + reader.GetValue(1) + "\t\t" + reader.GetValue(2) + "\t" + reader.GetValue(3) + "\t" + reader.GetValue(4)) ;
                    }
                }
            }
        }

        private void lbListsOfTasksToDo_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void btnAcceptTask_Click(object sender, EventArgs e)
        {
            // Move selected items from source ListBox to destination ListBox
            foreach (var selectedItem in lbListsOfTasksToDo.SelectedItems)
            {
                listBox1.Items.Add(selectedItem);
            }

            // Remove the selected items from the source ListBox
            while (lbListsOfTasksToDo.SelectedItems.Count > 0)
            {
                lbListsOfTasksToDo.Items.Remove(lbListsOfTasksToDo.SelectedItems[0]);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string searchText = txtSearchTask.Text;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string query = "SELECT * FROM TaskDetails WHERE TaskName LIKE '%"+ txtSearchTask.Text + "%'";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@SearchText", "%" + searchText + "%");

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        lbListsOfTasksToDo.Items.Clear();
                        while (reader.Read())
                        {
                            lbListsOfTasksToDo.Items.Add(reader.GetValue(0) + "\t" + reader.GetValue(1) + "\t\t" + reader.GetValue(2) + "\t" + reader.GetValue(3) + "\t" + reader.GetValue(4));
                        }

                        
                    }


                }
                catch(SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
               
            }
        }

        private void txtSearchTask_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT * FROM TaskDetails";
                SqlCommand command = new SqlCommand(query, connection);

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    lbListsOfTasksToDo.Items.Clear();
                    //lbListsOfTasksToDo.Items.Add(headings)
                    while (reader.Read())
                    {
                        lbListsOfTasksToDo.Items.Add(reader.GetValue(0) + "\t" + reader.GetValue(1) + "\t\t" + reader.GetValue(2) + "\t" + reader.GetValue(3) + "\t" + reader.GetValue(4));
                    }
                }

                txtSearchTask.Text = "";
            }
        }
    }
}
