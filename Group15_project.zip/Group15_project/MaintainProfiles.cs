﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Group15_project
{
    public partial class MaintainProfiles : Form
    {
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Siphokazi\Desktop\Group15_project\Profiles.mdf;Integrated Security=True";

        public MaintainProfiles()
        {
            InitializeComponent();
            //LoadProducts();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;
            string name = txtName.Text;
            string surname = txtSurname.Text;
            string email = txtEmail.Text;
            int contactNum = int.Parse(txtContactNumber.Text);
            string userCategory = CBUser.SelectedItem.ToString();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string updateQuery = "UPDATE UserDetails SET Password = @Password, Name = @Name, Surname = @Surname, Email = @Email, ContactNum = @ContactNum, UserCategory = @UserCategory WHERE Username = @Username";
                SqlCommand command = new SqlCommand(updateQuery, connection);
                command.Parameters.AddWithValue("@Username", username);
                command.Parameters.AddWithValue("@Password", password);
                command.Parameters.AddWithValue("@Name", name);
                command.Parameters.AddWithValue("@Surname", surname);
                command.Parameters.AddWithValue("@Email", email);
                command.Parameters.AddWithValue("@ContactNum", contactNum);
                command.Parameters.AddWithValue("@UserCategory", userCategory);

                int rowsAffected = command.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("User information updated successfully!");
                }
                else
                {
                    MessageBox.Show("User not found or update failed.");
                }
            }

        }
       

        private void cbAll_SelectedIndexChanged(object sender, EventArgs e)
        {
            


        }

        private void btnRegister_Click(object sender, EventArgs e)
        {

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string Username = txtUsername.Text;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string deleteQuery = "DELETE FROM UserDetails WHERE Username = @Username";
                SqlCommand command = new SqlCommand(deleteQuery, connection);
                command.Parameters.AddWithValue("@Username", Username);


                int rowsAffected = command.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Profile deleted successfully!");
                }
                else
                {
                    MessageBox.Show("Profile not found or delete failed.");
                }
            }
        }
    }
}
