﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Group15_project
{
    public partial class TrackLocation : Form
    {
        public TrackLocation()
        {
            InitializeComponent();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string street = txtStreet.Text;
            string suburb = txtSuburb.Text;
            string province = txtProvince.Text;
            string postalCode = txtPostalCode.Text;

            try
            {
                StringBuilder queryaddress = new StringBuilder();
                queryaddress.Append("https://www.google.com/maps?q=");

                if(street != string.Empty)
                {
                    queryaddress.Append(street + "," + "+");
                }
                if (suburb != string.Empty)
                {
                    queryaddress.Append(suburb + "," + "+");
                }
                if (province != string.Empty)
                {
                    queryaddress.Append(province + "," + "+");
                }
                if (postalCode != string.Empty)
                {
                    queryaddress.Append(postalCode + "," + "+");
                }

                webBrowser1.Navigate(queryaddress.ToString());

            }
            catch(SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
                

        }
    }
}
